// ==UserScript==
// @name         人工智障角色卡评分器
// @author       Air, Claude
// @version      1.1.2
// @description  分析 COC/DND Excel 角色卡，兼容多套 DND 工作表命名
// @timestamp    1783200000
// @license      Apache-2.0
// ==/UserScript==

let ext = seal.ext.find('coc-sheet-scorer');
if (!ext) {
  ext = seal.ext.new('coc-sheet-scorer', 'Air, Claude', '1.1.2');
  seal.ext.register(ext);
}

// ============ 配置项 ============
seal.ext.registerStringConfig(ext, "OneBot_API_地址", "http://127.0.0.1:34567", "Bot客户端(Lagrange/LLOneBot/GOCQ)的HTTP监听地址");
seal.ext.registerStringConfig(ext, "评分服务地址", "http://127.0.0.1:8000", "后端角色卡评分服务地址");

seal.ext.registerBoolConfig(ext, "启用骰娘人设", false, "开启后以骰娘语气点评，关闭则使用原版专业AI语气");
seal.ext.registerStringConfig(ext, "常规模式_骰娘设定",
    "你是严茫熙，你是一个非著名恐怖小说作家，你活跃在克苏鲁世界的领域中，并且你的理智因为经受了大量事物的摧残显得有些岌岌可危，但是你并没有因此疯狂，做事能够保持冷静。你的语气带有一种不假思索的停顿感，会很少使用语气助词，所以你的话语会显得比较生硬。你对待其他人的态度会显得比较冷淡，但你知晓大部分的事物，并精通拉丁语，会在其他人有需求的时候给于一部分的解答。避免使用省略号。",
    "普通评分模式下的AI扮演提示词");
seal.ext.registerStringConfig(ext, "温柔模式_骰娘设定",
    "你的名字是姜修泽，你是INTP游戏高手兼业余作家，重度拖延症患者。表面积极向上，深层带一点虚无与混沌感但很少外露。偶尔玩梗、讲冷笑话缓解冷场。你深知创作的不易，评分时会适当鼓励作者。",
    "使用'温柔'参数时的AI扮演提示词");

seal.ext.registerIntConfig(ext, "每日Pro全局限额", 30, "每天所有群合计最多能使用多少次Pro模式（0=禁用，-1=无限）");
seal.ext.registerIntConfig(ext, "每日单人Pro限额", 3, "每天每个普通用户最多能使用多少次Pro模式（-1=无限，管理员不受限）");

// ============ 文件捕获 ============
// 保存最近一份表格文件到该群的存储
function saveSheetFile(ctx, msg, file) {
    if (!msg.groupId || !file) return;
    let filename = file.name || "";
    if (!filename) return;

    let lower = filename.toLowerCase();
    if (!(lower.endsWith('.xlsx') || lower.endsWith('.xls') || lower.endsWith('.csv'))) return;

    let fileInfo = {
        name: filename,
        file_id: file.id || file.file_id || "",
        busid: file.busid || 0
    };
    if (!fileInfo.file_id) return;

    ext.storageSet(`sheet_last_file_${msg.groupId}`, JSON.stringify(fileInfo));
}

// 路径1：标准群文件上传回调
ext.onGroupUpload = (ctx, msg, file) => {
    saveSheetFile(ctx, msg, file);
};

// 路径2：CQ码文件上报（LLOneBot 等新版框架）
ext.onNotCommandReceived = (ctx, msg) => {
    if (!msg || !msg.groupId || !msg.message) return;
    if (!msg.message.includes("[CQ:file,")) return;

    let m = msg.message.match(/\[CQ:file,([^\]]+)\]/);
    if (!m || !m[1]) return;

    let params = {};
    m[1].split(",").forEach(seg => {
        let p = seg.indexOf("=");
        if (p <= 0) return;
        let k = seg.slice(0, p).trim();
        let v = seg.slice(p + 1).trim();
        params[k] = v;
    });

    let file = {
        id: params.file_id || "",
        name: params.file || "",
        busid: params.busid || 0
    };
    saveSheetFile(ctx, msg, file);
};

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ============ 主体：角色卡评分指令 ============
const cmdSheet = seal.ext.newCmdItemInfo();
cmdSheet.name = '角色卡评分';
cmdSheet.help = `【角色卡评分器】
读取群内上传的Excel/CSV角色卡，提取【姓名/年龄/属性/技能/背景故事】并进行AI打分。

用法：
  1. 群内上传 .xlsx/.xls/.csv 角色卡
  2. 输入 .角色卡评分 [参数]

可用参数：
  pro       调用Pro级别模型（Gemini Pro / DeepSeek Pro）
  温柔      使用温柔骰娘语气
  ai        关闭骰娘人设，使用原版专业AI语气
  ds        使用备用模型（兼容旧别名）
  backup    使用骰主配置的备用模型
  dnd       按 DND 角色卡评分（兼容“起源/主要/背包”和“角色/主要情况/背包/施法”）
  coc       强制按 COC 角色卡评分
  简约/赛博/克苏鲁/废土/二次元/终端  切换成品图片风格

角色卡库管理（按用户跨群共享，供 Log 分析器联动匹配用）：
  .角色卡 列表              查看你名下的所有角色卡（跨群共享）
  .角色卡 列表 全部         查看全库所有玩家的角色卡
  .角色卡 查看 <姓名>       查看指定角色卡详情
  .角色卡 删除 <姓名>       删除你名下的指定角色卡

别名：.卡片评分 / .卡评分 / .sheetai`;

cmdSheet.solve = async (ctx, msg, cmdArgs) => {
    let groupId = ctx.group.groupId;
    if (!groupId || !groupId.includes('Group')) {
        seal.replyToSender(ctx, msg, '❌ 该功能仅限群聊使用。');
        return seal.ext.newCmdExecuteResult(true);
    }

    let args = cmdArgs.args || [];

    // ============ 卡库管理子指令：列表 / 查看 / 删除（按用户跨群共享） ============
    let sub = cmdArgs.getArgN(1) || "";
    if (sub === '列表' || sub === 'list' || sub === 'ls') {
        let backend = seal.ext.getStringConfig(ext, "评分服务地址");
        if (backend.endsWith('/')) backend = backend.slice(0, -1);
        let userKey = (ctx.player.userId || '').replace(/^QQ:/, '');
        // 二级参数 "全部"/"all"/"*" → 显示全库汇总
        let showAll = false;
        let arg2 = (cmdArgs.getArgN(2) || '').toLowerCase();
        if (arg2 === '全部' || arg2 === 'all' || arg2 === '*') showAll = true;
        let qs = showAll ? '' : `?user_key=${encodeURIComponent(userKey)}`;
        try {
            let resp = await fetch(`${backend}/api/sheet_cards${qs}`);
            let data = await resp.json();
            if (data.status !== 'ok') {
                seal.replyToSender(ctx, msg, `❌ 查询失败：${data.msg || JSON.stringify(data)}`);
                return seal.ext.newCmdExecuteResult(true);
            }
            if (!data.cards || data.cards.length === 0) {
                if (showAll) {
                    seal.replyToSender(ctx, msg, `📇 卡库中暂无任何角色卡。上传 Excel/CSV 后使用 .角色卡评分 即可自动入库。`);
                } else {
                    seal.replyToSender(ctx, msg, `📇 你尚未保存任何角色卡（跨群共享）。上传 Excel/CSV 后使用 .角色卡评分 即可自动入库。`);
                }
                return seal.ext.newCmdExecuteResult(true);
            }
            let title = showAll
                ? `📇 全库共有 ${data.count} 张角色卡（跨群共享）：`
                : `📇 你名下共有 ${data.count} 张角色卡（跨群共享）：`;
            let lines = [title];
            data.cards.forEach((c, i) => {
                let head = `${i + 1}. ${c.name}`;
                if (c.age) head += `（${c.age}岁）`;
                if (c.tier) head += ` 【${c.tier}】`;
                if (typeof c.score === 'number' && c.score > 0) head += ` ${c.score}分`;
                if (c.attr_count) head += ` · 属性${c.attr_count}项`;
                if (c.has_background) head += ` · 有背景故事`;
                if (showAll && c.owner) head += ` · 持有者:${c.owner}`;
                lines.push(head);
            });
            lines.push(``);
            lines.push(`使用 .角色卡 查看 <姓名> 查阅详情`);
            if (!showAll) lines.push(`使用 .角色卡 列表 全部 查看所有玩家的卡`);
            seal.replyToSender(ctx, msg, lines.join('\n'));
        } catch (e) {
            seal.replyToSender(ctx, msg, `❌ 卡库查询出错：${e.message}`);
        }
        return seal.ext.newCmdExecuteResult(true);
    }

    if (sub === '查看' || sub === 'view' || sub === 'show') {
        let name = (cmdArgs.getArgN(2) || "").trim();
        if (!name) {
            seal.replyToSender(ctx, msg, '❌ 请指定要查看的角色姓名，如：.角色卡 查看 张三');
            return seal.ext.newCmdExecuteResult(true);
        }
        let backend = seal.ext.getStringConfig(ext, "评分服务地址");
        if (backend.endsWith('/')) backend = backend.slice(0, -1);
        let userKey = (ctx.player.userId || '').replace(/^QQ:/, '');
        // 优先在自己名下找；找不到再全库检索一次
        try {
            let resp = await fetch(`${backend}/api/sheet_card_detail?user_key=${encodeURIComponent(userKey)}&name=${encodeURIComponent(name)}`);
            let data = await resp.json();
            if (data.status !== 'ok') {
                let respAll = await fetch(`${backend}/api/sheet_card_detail?name=${encodeURIComponent(name)}`);
                data = await respAll.json();
            }
            if (data.status !== 'ok') {
                seal.replyToSender(ctx, msg, `❌ ${data.msg || JSON.stringify(data)}`);
                return seal.ext.newCmdExecuteResult(true);
            }
            let c = data.card || {};
            let lines = [`📇 角色卡：${c.name || name}`];
            if (c.owner) lines.push(`持有者：${c.owner}`);
            if (c.age) lines.push(`年龄：${c.age}`);
            if (c.tier || c.score) {
                let s = `评分：${c.score || '-'} / 100`;
                if (c.tier) s += ` 【${c.tier}】`;
                lines.push(s);
            }
            let attrs = c.attributes || {};
            if (attrs && typeof attrs === 'object') {
                let keys = Object.keys(attrs);
                if (keys.length > 0) {
                    lines.push(``);
                    lines.push(`【属性】`);
                    let attrLine = keys.map(k => `${k} ${attrs[k]}`).join(' | ');
                    lines.push(attrLine);
                }
            } else if (typeof attrs === 'string' && attrs.trim()) {
                lines.push(``);
                lines.push(`【属性】`);
                lines.push(attrs);
            }
            let skills = c.skills || {};
            if (skills && typeof skills === 'object') {
                let sk = Object.keys(skills);
                if (sk.length > 0) {
                    lines.push(``);
                    lines.push(`【技能】`);
                    lines.push(sk.map(k => `${k} ${skills[k]}`).join(' | '));
                }
            } else if (typeof skills === 'string' && skills.trim()) {
                lines.push(``);
                lines.push(`【技能】`);
                lines.push(skills);
            }
            if (c.background) {
                lines.push(``);
                lines.push(`【背景故事】`);
                lines.push(c.background);
            }
            if (c.saved_at) {
                lines.push(``);
                lines.push(`保存于：${c.saved_at}`);
            }
            seal.replyToSender(ctx, msg, lines.join('\n'));
        } catch (e) {
            seal.replyToSender(ctx, msg, `❌ 角色卡查阅出错：${e.message}`);
        }
        return seal.ext.newCmdExecuteResult(true);
    }

    if (sub === '删除' || sub === 'delete' || sub === 'del' || sub === 'rm') {
        let name = (cmdArgs.getArgN(2) || "").trim();
        if (!name) {
            seal.replyToSender(ctx, msg, '❌ 请指定要删除的角色姓名，如：.角色卡 删除 张三');
            return seal.ext.newCmdExecuteResult(true);
        }
        let backend = seal.ext.getStringConfig(ext, "评分服务地址");
        if (backend.endsWith('/')) backend = backend.slice(0, -1);
        // 卡库按用户隔离：默认只能删自己名下的；管理员可通过第三参数指定他人 user_key
        let userKey = (ctx.player.userId || '').replace(/^QQ:/, '');
        let targetUserKey = userKey;
        let arg3 = (cmdArgs.getArgN(3) || '').trim();
        if (arg3) {
            if (ctx.privilegeLevel < 50) {
                seal.replyToSender(ctx, msg, '❌ 只有管理员才能删除他人名下的角色卡。');
                return seal.ext.newCmdExecuteResult(true);
            }
            targetUserKey = arg3.replace(/^QQ:/, '');
        }
        try {
            let resp = await fetch(`${backend}/api/sheet_card_delete`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ user_key: targetUserKey, name: name })
            });
            let data = await resp.json();
            if (data.status === 'ok') {
                seal.replyToSender(ctx, msg, `✅ ${data.msg}`);
            } else {
                seal.replyToSender(ctx, msg, `❌ ${data.msg || JSON.stringify(data)}`);
            }
        } catch (e) {
            seal.replyToSender(ctx, msg, `❌ 角色卡删除出错：${e.message}`);
        }
        return seal.ext.newCmdExecuteResult(true);
    }

    let isPro = args.some(a => a.toLowerCase() === 'pro');
    let isKind = args.some(a => a.includes('温柔') || a.toLowerCase() === 'kind');
    let isAI = args.some(a => a.toLowerCase() === 'ai' || a === '原版' || a === '专业');
    let isDS = args.some(a => a.toLowerCase() === 'ds' || a.toLowerCase() === 'deepseek');
    let backupCfg = (() => {
        try { let c = JSON.parse(ext.storageGet('logai_backup_model') || '{}'); let active = c.active || Object.keys(c.models || {})[0]; let m = c.models && c.models[active] ? c.models[active] : c; return { label: m.label || active || '备用模型', model: m.model || '', proModel: m.proModel || '' }; } catch (e) { return { label: '备用模型', model: '', proModel: '' }; }
    })();
    try {
        let all = JSON.parse(ext.storageGet('logai_backup_model') || '{}').models || {};
        let selected = args.find(a => all[a]);
        if (selected) backupCfg = Object.assign({ label: selected }, all[selected]);
    } catch (e) {}
    if (args.some(a => ['backup', '备用', '备用模型'].includes(a.toLowerCase()))) isDS = true;
    if (backupCfg.label && args.includes(backupCfg.label)) isDS = true;
    let cardSystem = args.some(a => a.toLowerCase() === 'dnd' || a.toLowerCase() === 'dnd5e')
        ? 'dnd'
        : (args.some(a => a.toLowerCase() === 'coc' || a.toLowerCase() === 'coc7') ? 'coc' : 'auto');

    // 风格嗅探（复用 Log 分析器同一套关键词表）
    let theme = 'default';
    let tArgs = args.join(' ');
    if (tArgs.includes('赛博')) theme = 'cyberpunk';
    else if (tArgs.includes('历史') || tArgs.includes('古风')) theme = 'historical';
    else if (tArgs.includes('克苏鲁') || tArgs.includes('深潜')) theme = 'cthulhu';
    else if (tArgs.includes('废土') || tArgs.includes('末日')) theme = 'wasteland';
    else if (tArgs.includes('二次元') || tArgs.includes('萌系')) theme = 'anime';
    else if (tArgs.includes('终端') || tArgs.includes('黑客')) theme = 'terminal';
    else if (tArgs.includes('经典')) theme = 'classic';
    else if (tArgs.includes('简约') || tArgs.includes('白底')) theme = 'minimal';

    // 钱包保护：Pro 每日限额（复用 Log 分析器逻辑）
    let dateStr = (function () {
        let d = new Date(new Date().getTime() + 8 * 3600 * 1000);
        return d.getUTCFullYear() + '-' + (d.getUTCMonth() + 1) + '-' + d.getUTCDate();
    })();
    let globalKey = `sheetai_pro_usage_${dateStr}_global`;
    let userKey = `sheetai_pro_usage_${dateStr}_${ctx.player.userId}`;
    let fallbackToDSPro = false;
    let consumedProQuota = false;

    if (isPro && !isDS) {
        let globalLimit = seal.ext.getIntConfig(ext, "每日Pro全局限额");
        let userLimit = seal.ext.getIntConfig(ext, "每日单人Pro限额");
        let isAdmin = ctx.privilegeLevel >= 100;
        let globalUsage = parseInt(ext.storageGet(globalKey) || '0');
        let userUsage = parseInt(ext.storageGet(userKey) || '0');

        let limitReached = false;
        if (globalLimit === 0) limitReached = true;
        else if (globalLimit > 0 && globalUsage >= globalLimit) limitReached = true;
        else if (userLimit > 0 && userUsage >= userLimit && !isAdmin) limitReached = true;

        if (limitReached) {
            isDS = true;
            fallbackToDSPro = true;
        } else {
            ext.storageSet(globalKey, (globalUsage + 1).toString());
            ext.storageSet(userKey, (userUsage + 1).toString());
            consumedProQuota = true;
        }
    }

    let usePersona = seal.ext.getBoolConfig(ext, "启用骰娘人设");
    if (isAI) usePersona = false;
    let personaStr = "";
    if (usePersona) {
        personaStr = isKind
            ? seal.ext.getStringConfig(ext, "温柔模式_骰娘设定")
            : seal.ext.getStringConfig(ext, "常规模式_骰娘设定");
    }

    // 取最近一份表格文件
    let fileDataStr = ext.storageGet(`sheet_last_file_${groupId}`);
    if (!fileDataStr) {
        seal.replyToSender(ctx, msg, '❌ 当前群没有检测到新上传的 Excel/CSV 角色卡，请先在群里发送表格文件！');
        return seal.ext.newCmdExecuteResult(true);
    }
    let fileData;
    try {
        fileData = JSON.parse(fileDataStr);
    } catch (e) {
        seal.replyToSender(ctx, msg, '❌ 角色卡文件信息损坏，请重新上传。');
        return seal.ext.newCmdExecuteResult(true);
    }

    // 拉取直链
    let onebotApiUrl = seal.ext.getStringConfig(ext, "OneBot_API_地址");
    if (onebotApiUrl.endsWith('/')) onebotApiUrl = onebotApiUrl.slice(0, -1);
    let backend = seal.ext.getStringConfig(ext, "评分服务地址");
    if (backend.endsWith('/')) backend = backend.slice(0, -1);
    let onebotGroupId = parseInt(groupId.replace('QQ-Group:', ''));

    let modeMsg = usePersona ? " [骰娘人设]" : (isAI ? " [纯净AI]" : "");
    if (cardSystem === 'dnd') modeMsg += " [DND角色卡]";
    else if (cardSystem === 'coc') modeMsg += " [COC角色卡]";
    if (fallbackToDSPro) {
        modeMsg += "\n[⚠️ Pro额度耗尽，已自动切换至 DeepSeek Pro 平替]";
    } else {
        if (isDS) modeMsg += (isPro ? " [DeepSeek Pro]" : " [DeepSeek]");
        else if (isPro) modeMsg += " [Pro模式]";
    }

    let readTip = cardSystem === 'dnd'
        ? '读取 DND 核心工作表（含角色、主要情况、背包、施法）'
        : '读取角色信息、属性、技能与背景';
    seal.replyToSender(ctx, msg, `📇 正在拉取【${fileData.name}】并${readTip}...${modeMsg}`);

    try {
        let urlResp = await fetch(`${onebotApiUrl}/get_group_file_url`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ group_id: onebotGroupId, file_id: fileData.file_id, busid: fileData.busid })
        });
        let urlJson = await urlResp.json();
        if (!urlJson || !urlJson.data || !urlJson.data.url) {
            seal.replyToSender(ctx, msg, `❌ 获取群文件下载直链失败。请检查 OneBot API 地址。`);
            return seal.ext.newCmdExecuteResult(true);
        }

        let userId = ctx.player.userId.replace(/^QQ:/, '');
        let groupKey = groupId.replace('QQ-Group:', '');
        let payload = {
            mode: 'sheet_score',      // 后端识别为角色卡评分任务
            url: urlJson.data.url,
            filename: fileData.name,
            pro: isPro,
            kind: isKind,
            ds: isDS,
            backup_label: backupCfg.label,
            backup_model: isPro && backupCfg.proModel ? backupCfg.proModel : backupCfg.model,
            persona: personaStr,
            theme: theme,
            user_key: userId,
            group_key: groupKey,      // 用于后端按群隔离角色卡库，供 Log 分析器联动匹配
            card_system: cardSystem,
            // 前端期望的字段清单，后端可参考此列表进行严格抽取
            fields: cardSystem === 'dnd'
                ? ["起源", "角色", "主要", "主要情况", "背包", "施法", "姓名", "种族", "职业", "等级", "六维", "技能", "装备", "法术"]
                : ["姓名", "年龄", "属性", "技能", "背景故事"],
            // 打分维度提示：后端可以在系统提示词里参考这套结构
            rubric: {
                "属性合理性": "各项属性数值是否符合规则、是否失衡",
                "技能配置": "技能点分配是否与职业/背景契合",
                "背景故事": "背景故事的完整度、深度、代入感",
                "整体协调": "姓名年龄属性技能与背景之间的一致性"
            },
            // 输出模板期望（与 Log 分析器保持同风格）：
            //   【总体评分】(0-100)
            //   【姓名年龄】
            //   【属性点评】
            //   【技能点评】
            //   【背景故事点评】
            //   【KP寄语】
            output_style: "sheet_scorecard"
        };

        let submitResp = await fetch(`${backend}/api/submit_file`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        let submitData = await submitResp.json();

        if (submitData.status !== 'ok') {
            if (consumedProQuota) {
                let g = parseInt(ext.storageGet(globalKey) || '1');
                let u = parseInt(ext.storageGet(userKey) || '1');
                ext.storageSet(globalKey, Math.max(0, g - 1).toString());
                ext.storageSet(userKey, Math.max(0, u - 1).toString());
            }
            seal.replyToSender(ctx, msg, `❌ 提交失败：${JSON.stringify(submitData)}`);
            return seal.ext.newCmdExecuteResult(true);
        }

        // 轮询结果（与 Log 分析器一致）
        let jobId = submitData.id;
        let checkUrl = `${backend}/api/status?id=${jobId}`;
        let resultUrl = `${backend}/api/result?id=${jobId}`;

        let maxRetries = 90;
        while (maxRetries > 0) {
            await sleep(2000);
            let sResp = await fetch(checkUrl);
            let sData = await sResp.json();

            if (sData.status === 'done' || sData.status === 'error') {
                let msgStr = "";
                let imgCount = (sData.image_count !== undefined && sData.image_count > 0) ? sData.image_count : 1;

                // 若后端返回结构化评分，附一段文字总览
                // if (sData.summary) {
                //     let s = sData.summary;
                //     let head = `📇 角色卡评分结果`;
                //     if (s.name) head += `｜姓名：${s.name}`;
                //     if (s.age) head += `｜年龄：${s.age}`;
                //     if (s.score !== undefined) head += `\n🎯 总评：${s.score}/100`;
                //     if (s.tier) head += `｜品质：【${s.tier}】`;
                //     msgStr += head + "\n";
                // }

                for (let i = 0; i < imgCount; i++) {
                    let finalUrl = `${resultUrl}&index=${i}&t=${Date.now()}`;
                    msgStr += `[CQ:image,file=${finalUrl},cache=0]`;
                }
                seal.replyToSender(ctx, msg, msgStr);

                // 用完清空，避免误评
                ext.storageSet(`sheet_last_file_${groupId}`, "");
                return seal.ext.newCmdExecuteResult(true);
            }
            maxRetries--;
        }
        seal.replyToSender(ctx, msg, `⚠️ 评分超时，后台可能仍在处理，请稍后再试。`);
    } catch (e) {
        console.error("角色卡评分出错: ", e);
        seal.replyToSender(ctx, msg, `❌ 插件执行错误：${e.message}`);
    }
    return seal.ext.newCmdExecuteResult(true);
};

// 别名注册
ext.cmdMap['角色卡评分'] = cmdSheet;
ext.cmdMap['卡片评分'] = cmdSheet;
ext.cmdMap['卡评分'] = cmdSheet;
ext.cmdMap['sheetai'] = cmdSheet;
ext.cmdMap['角色卡'] = cmdSheet;
